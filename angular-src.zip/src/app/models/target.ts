/*
  Created by khoaVC
  Role: Guest
  Time: 10:00 21/06/2022
  Interface: Target
*/
export interface Target {
  id?: number;
  name?: string;
}
