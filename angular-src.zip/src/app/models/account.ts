export interface Account {
  id?: number;
  userName?: string;
  encryptPassword?: string;
  isEnabled?: boolean;
  verificationCode?: string;
}
