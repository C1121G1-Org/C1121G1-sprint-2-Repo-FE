export interface AccountDto {
  id?: number;
  userName?: string;
  encryptPassword?: string;
  isEnabled?: boolean;
  verificationCode?: string;
}

