import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guest-search',
  templateUrl: './guest-search.component.html',
  styleUrls: ['./guest-search.component.css']
})
export class GuestSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
