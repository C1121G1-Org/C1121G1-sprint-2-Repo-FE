import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guest-top100',
  templateUrl: './guest-top100.component.html',
  styleUrls: ['./guest-top100.component.css']
})
export class GuestTop100Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
