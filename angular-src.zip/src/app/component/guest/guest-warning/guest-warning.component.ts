import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guest-warning',
  templateUrl: './guest-warning.component.html',
  styleUrls: ['./guest-warning.component.css']
})
export class GuestWarningComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
