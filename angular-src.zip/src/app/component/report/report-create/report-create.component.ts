import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-create',
  templateUrl: './report-create.component.html',
  styleUrls: ['./report-create.component.css']
})
export class ReportCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
