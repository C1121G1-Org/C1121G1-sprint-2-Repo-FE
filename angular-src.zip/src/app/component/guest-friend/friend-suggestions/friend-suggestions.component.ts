import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-friend-suggestions',
  templateUrl: './friend-suggestions.component.html',
  styleUrls: ['./friend-suggestions.component.css']
})
export class FriendSuggestionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
