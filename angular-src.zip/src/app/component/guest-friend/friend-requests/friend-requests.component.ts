import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-friend-requests',
  templateUrl: './friend-requests.component.html',
  styleUrls: ['./friend-requests.component.css']
})
export class FriendRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
