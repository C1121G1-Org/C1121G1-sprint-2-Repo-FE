import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-money-charge',
  templateUrl: './money-charge.component.html',
  styleUrls: ['./money-charge.component.css']
})
export class MoneyChargeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
